package com.spring.crudsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudsystemApplication.class, args);
	}

}
